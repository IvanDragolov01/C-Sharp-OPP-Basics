﻿namespace _06.Animals
{
	interface ISoundProducable
	{
		string ProduceSound();
	}
}
