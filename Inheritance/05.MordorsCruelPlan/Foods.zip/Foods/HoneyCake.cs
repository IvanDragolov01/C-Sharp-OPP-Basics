﻿namespace _05.MordorsCruelPlan.Foods
{
	public class HoneyCake : Food
	{
		public HoneyCake(int pointsOfHappiness) : base(pointsOfHappiness)
		{ }
	}
}
