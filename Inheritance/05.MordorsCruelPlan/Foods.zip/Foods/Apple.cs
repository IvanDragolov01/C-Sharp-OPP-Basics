﻿namespace _05.MordorsCruelPlan.Foods
{
	public class Apple : Food
	{
		public Apple(int pointsOfHappiness) : base(pointsOfHappiness)
		{ }
	}
}
