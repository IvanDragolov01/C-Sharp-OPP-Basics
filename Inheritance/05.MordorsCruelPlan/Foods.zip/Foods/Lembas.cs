﻿namespace _05.MordorsCruelPlan.Foods
{
	public class Lembas : Food
	{
		public Lembas(int pointsOfHappiness) : base(pointsOfHappiness)
		{ }
	}
}
