﻿namespace _05.MordorsCruelPlan.Foods
{
	public class OtherFood : Food
	{
		public OtherFood(int pointsOfHappiness) : base(pointsOfHappiness)
		{ }
	}
}
