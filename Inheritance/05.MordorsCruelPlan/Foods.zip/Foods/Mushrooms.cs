﻿namespace _05.MordorsCruelPlan.Foods
{
	public class Mushrooms : Food
	{
		public Mushrooms(int pointsOfHappiness) : base(pointsOfHappiness)
		{ }
	}
}
