﻿namespace _05.MordorsCruelPlan.Foods
{
	public class Melon : Food
	{
		public Melon(int pointsOfHappiness) : base(pointsOfHappiness)
		{ }
	}
}
