﻿namespace _05.MordorsCruelPlan.Foods
{
	public class Cram : Food
	{
		public Cram(int pointsOfHappiness) : base(pointsOfHappiness)
		{ }
	}
}
