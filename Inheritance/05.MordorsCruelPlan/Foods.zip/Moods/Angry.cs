﻿namespace _05.MordorsCruelPlan.Moods
{
	public class Angry : Mood
	{
	}
}
