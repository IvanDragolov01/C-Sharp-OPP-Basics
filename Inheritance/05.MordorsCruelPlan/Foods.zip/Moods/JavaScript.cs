﻿namespace _05.MordorsCruelPlan.Moods
{
	public class JavaScript : Mood
	{
	}
}
