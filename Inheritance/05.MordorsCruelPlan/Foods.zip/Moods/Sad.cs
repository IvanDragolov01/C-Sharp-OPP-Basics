﻿namespace _05.MordorsCruelPlan.Moods
{
	public class Sad : Mood
	{
	}
}
