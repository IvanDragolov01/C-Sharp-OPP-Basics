﻿using System;
using System.Collections.Generic;
using System.Reflection;

namespace _04.Opinion_Poll
{
	class Program
	{
		static void Main(string[] args)
		{
			PrintingPersons Persons = new PrintingPersons();
			int membersNumber = int.Parse(Console.ReadLine());
			Person member;
			List<Person> people = new List<Person>();

			while (membersNumber > 0)
			{
				string[] personData = Console.ReadLine().Split();
				member = new Person(personData[0], int.Parse(personData[1]));
				
				if (member.Age >= 30)
				{
					Persons.AddMember(member);
				}

				membersNumber--;
			}

			foreach (PrintingPersons value in List<Person>)
			{
				Console.WriteLine(value);
			}
		}
	}
}
