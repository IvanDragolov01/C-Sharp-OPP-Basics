﻿using DefiningClasses;
using System;

namespace DefiningClasses
{
	public class StartUp
	{
		static void Main(string[] args)
		{
			Person nameAndAge = new Person();
			nameAndAge.Name = "Gosho";
			nameAndAge.Age = 18;
			string result = nameAndAge.PrintNameAndAge();
			Console.WriteLine(result);
		}
	}
}