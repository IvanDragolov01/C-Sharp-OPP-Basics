﻿
using System;

namespace DefiningClasses
{
	public class Person
	{
		int age;
		string name;

		public string Name { get => name; set => name = value; }

		public int Age { get => age; set => age = value; }

		public string PrintNameAndAge()
		{
			return $"{this.name} {this.age}";
		}
	}
}
