﻿namespace _01.DefineanInterfaceIPerson
{
	public interface IPerson
	{
		int Age
		{
			get;
		}

		string Name
		{
			get;
		}
	}
}