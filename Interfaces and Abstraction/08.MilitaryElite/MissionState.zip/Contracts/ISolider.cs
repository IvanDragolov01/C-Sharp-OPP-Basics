﻿namespace _08.MilitaryElite.Contracts
{
	public interface ISolider
	{
		int Id
		{
			get;
		}

		string FirstName
		{
			get;
		}

		string LastName
		{
			get;
		}
	}
}
