﻿namespace _08.MilitaryElite.Contracts
{
	public interface IPrivate : ISolider
	{
		decimal Salary
		{
			get;
		}
	}
}
