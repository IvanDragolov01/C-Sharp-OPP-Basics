﻿namespace _08.MilitaryElite.Contracts
{
	interface ISpy : ISolider
	{
		int CodeNumber
		{
			get;
		}
	}
}
