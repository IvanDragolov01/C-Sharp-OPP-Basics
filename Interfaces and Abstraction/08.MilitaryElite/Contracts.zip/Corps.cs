﻿namespace _08.MilitaryElite.Contracts
{
	public enum Corps
	{
		Airforces, Marines
	}
}
