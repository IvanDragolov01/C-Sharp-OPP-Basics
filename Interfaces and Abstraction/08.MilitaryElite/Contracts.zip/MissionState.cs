﻿namespace _08.MilitaryElite.Contracts
{
	public enum MissionState
	{
		inProgress, Finished
	}
}
