﻿namespace _04.Telephony
{
	public interface ICall
	{
		string Call(string phone);
	}
}