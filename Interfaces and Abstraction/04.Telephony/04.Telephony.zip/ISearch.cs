﻿namespace _04.Telephony
{
	public interface ISearch
	{
		string Browse(string website);
	}
}