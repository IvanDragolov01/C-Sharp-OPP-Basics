﻿namespace _06.BirthdayCelebrations
{
	public interface IHuman
	{
		string Name
		{
			get;
		}

		int Age
		{
			get;
		}
	}
}