﻿namespace _06.BirthdayCelebrations
{
	public interface IId
	{
		string Id
		{
			get;
		}
	}
}
