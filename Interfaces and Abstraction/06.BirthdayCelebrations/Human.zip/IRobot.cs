﻿namespace _06.BirthdayCelebrations
{
	public interface IRobot
	{
		string Model
		{
			get;
		}
	}
}
