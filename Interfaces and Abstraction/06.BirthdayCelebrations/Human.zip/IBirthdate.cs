﻿namespace _06.BirthdayCelebrations
{
	public interface IBirthdate
	{
		string Birthday
		{
			get;
		}
	}
}
