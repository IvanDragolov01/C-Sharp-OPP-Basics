﻿namespace _06.BirthdayCelebrations
{
	public interface IPet
	{
		string Name
		{
			get;
		}
	}
}
