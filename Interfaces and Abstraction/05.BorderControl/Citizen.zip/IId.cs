﻿namespace _05.BorderControl
{
	public interface IId
	{
		string Id
		{
			get;
		}
	}
}
