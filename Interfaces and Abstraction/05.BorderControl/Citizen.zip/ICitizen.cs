﻿namespace _05.BorderControl
{
	public interface ICitizen
	{
		string Name
		{
			get;
		}

		int Age
		{
			get;
		}
	}
}
