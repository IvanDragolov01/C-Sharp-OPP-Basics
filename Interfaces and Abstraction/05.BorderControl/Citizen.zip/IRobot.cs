﻿namespace _05.BorderControl
{
	public interface IRobot
	{
		string Model
		{
			get;
		}
	}
}
