﻿namespace _07.FoodShortage
{
	public interface IBirthdate
	{
		string Birthday
		{
			get;
		}
	}
}
