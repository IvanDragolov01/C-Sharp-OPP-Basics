﻿namespace _07.FoodShortage
{
	public interface IRebel
	{
		string Group
		{
			get;
		}
	}
}
