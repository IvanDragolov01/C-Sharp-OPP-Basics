﻿namespace _07.FoodShortage
{
	public interface IHuman
	{
		string Name
		{
			get;
		}

		int Age
		{
			get;
		}
	}
}