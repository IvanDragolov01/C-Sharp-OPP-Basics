﻿namespace _07.FoodShortage
{
	public interface IId
	{
		string Id
		{
			get;
		}
	}
}
