﻿namespace _02.Multiple_Implementation
{
	internal interface IBirthable
	{
		string Birthdate { get; }
	}
}