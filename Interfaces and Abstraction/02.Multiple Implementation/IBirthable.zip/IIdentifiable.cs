﻿namespace _02.Multiple_Implementation
{
	internal interface IIdentifiable
	{
		string Id { get; }
	}
}