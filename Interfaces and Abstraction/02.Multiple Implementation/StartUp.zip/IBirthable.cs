﻿namespace _02.Multiple_Implementation
{
	public interface IBirthable
	{
		string Birthdate
		{
			get;
		}
	}
}