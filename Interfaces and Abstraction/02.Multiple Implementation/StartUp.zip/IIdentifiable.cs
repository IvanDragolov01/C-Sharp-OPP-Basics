﻿namespace _02.Multiple_Implementation
{
	public interface IIdentifiable
	{
		string Id
		{
			get;
		}
	}
}