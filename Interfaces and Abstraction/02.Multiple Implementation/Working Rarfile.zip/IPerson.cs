﻿namespace PersonInfo
{
	public interface IPerson
	{
		int Age
		{
			get;
		}

		string Name
		{
			get;
		}
	}
}