﻿namespace _09.CollectionHierarchy
{
	public interface IAddCollection
	{
		void Add(string element);
	}
}
