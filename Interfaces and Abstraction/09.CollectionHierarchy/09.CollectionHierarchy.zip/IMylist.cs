﻿namespace _09.CollectionHierarchy
{
	public interface IMylist : IAddRemoveCollection
	{
		int NumberOfElements
		{
			get;
		}
	}
}
