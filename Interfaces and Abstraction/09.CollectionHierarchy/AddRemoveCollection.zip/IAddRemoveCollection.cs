﻿namespace _09.CollectionHierarchy
{
	public interface IAddRemoveCollection : IAddCollection
	{
		void Remove();
		void GetRemovedElements();
	}
}
