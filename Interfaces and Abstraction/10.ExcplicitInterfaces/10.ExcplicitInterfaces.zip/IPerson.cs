﻿namespace _10.ExcplicitInterfaces
{
	public interface IPerson
	{
		string Name
		{
			get;
		}

		int Age
		{
			get;
		}

		void GetName();
	}
}
