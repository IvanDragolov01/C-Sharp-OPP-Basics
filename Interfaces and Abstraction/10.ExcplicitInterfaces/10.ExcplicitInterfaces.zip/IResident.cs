﻿namespace _10.ExcplicitInterfaces
{
	public interface IResident
	{
		string Country
		{
			get;
		}

		void GetName();
	}
}
