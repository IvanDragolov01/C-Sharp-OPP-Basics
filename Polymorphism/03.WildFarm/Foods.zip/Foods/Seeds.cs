﻿namespace _03._WildFarm
{
	class Seeds : Food
	{
		public Seeds(int quantity)
			: base(quantity) { }
	}
}
