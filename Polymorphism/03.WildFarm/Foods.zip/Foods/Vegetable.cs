﻿namespace _03._WildFarm
{
	public class Vegetable : Food
	{
		public Vegetable(int quantity)
			: base(quantity) { }
	}
}
