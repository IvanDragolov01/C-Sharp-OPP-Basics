﻿public enum Weather
{
	Rainy, Foggy, Sunny
}
